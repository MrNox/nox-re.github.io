#include <stdio.h>
#include <stdlib.h>
#include <dlfcn.h>


void main() {

	void *handle;
	void (*write)(void);
    	char *error;

	handle = dlopen("//system//lib//libc.so", RTLD_LAZY);
	if (!handle) {
        	fprintf(stderr, "%s\n", dlerror());
        	exit(EXIT_FAILURE);
   	}  
	
	*(void **) (&write) = dlsym(handle, "write");

  	if ((error = dlerror()) != NULL)  {
        	fprintf(stderr, "%s\n", error);
        	exit(EXIT_FAILURE);
    	}

	printf("function write %x\n", (*write));
	dlclose(handle);
	exit(EXIT_SUCCESS);

}
